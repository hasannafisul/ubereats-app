import React from 'react'
import feed from "../Images/feed.png";
import your_restaurant from "../Images/your_restaurant.png";
import delivered from "../Images/delivered.png";
import { useMediaQuery } from '@mui/material';
import { Link } from 'react-router-dom';
const BigscreenOnCards = () => {
    const matches1 = useMediaQuery('(min-width:1230px)');
    return (
    <>

<div style={{padding:'0px 20px',margin:matches1?'300px 0px 60px 0px':'60px 0px',paddingLeft:'20px'}}>
<div className="row">

    <div style={{display:'flex',justifyContent:'center',alignItems:'center'}}>
    <div className='col-sm-4'>
  

<div style={{width: "100%"}}>
  <img src={feed} class="card-img-top" />
 
</div>

<div >
    <span style={{fontSize:'2.3vw',fontWeight:'500',color:'#000'}}>Feed your employees</span>
</div>
 <div >

    <Link to="/" style={{color:'#000'}}>Create a business account</Link>
 </div>


</div>

<div className='col-sm-4 mx-2'>
<div style={{width: "100%"}}>
  <img src={feed} class="card-img-top" />
 
</div>

<div>
    <span style={{fontSize:'2.3vw',fontWeight:'500',color:'#000'}}>Your restaurant, delivered </span>
</div>

<div>
    <Link to="/" style={{color:'#000'}}>Add your restaurant</Link>

</div>

</div>

<div className='col-sm-4'>
<div style={{width: "100%"}}>
  <img src={feed} class="card-img-top" />
  
</div>

<div>
    <span style={{fontSize:'2.3vw',fontWeight:'500',color:'#000'}}>Deliver with Uber Eats</span>
</div>

<div>

    <Link to="/" style={{color:'#000'}}>Sign up to deliver</Link>
</div>


</div>

    </div>
    </div>
    </div>
    </>
  )
}

export default BigscreenOnCards
