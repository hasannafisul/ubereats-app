import { useMediaQuery } from '@mui/material'
import React, { useState,useEffect } from 'react'
import OrderFood from './OrderFood'
import { Link } from "react-router-dom";
import "../App.css";


const Navbar = () => {
const matches1 = useMediaQuery (`(max-width:992px)`);
const matches2 = useMediaQuery (`(min-width:720px)`);
const matches3 = useMediaQuery (`(min-width:1200px)`);
  

const [side, setside] = useState('0')
const [offset, setOffset] = useState(0);
const [colorChange, setColorchange] = useState(false);
const [inputfield, setinputfield] = useState(false)
const openNav=()=> {
    document.getElementById("mySidenav").style.width = "250px";
  }
const closeNav=()=> {
    document.getElementById("mySidenav").style.width = "0px";
  }

  const changeNavbarColor = () =>{
    if(window.scrollY >= 80){
    setColorchange(true);
    }
    else{
    setColorchange(false);
    }
  };
  window.addEventListener("scroll",changeNavbarColor);

const changetransition=()=>{
  if (window.scrollY >= 350 ) {
    // document.querySelector("#check").style.display='flex';
    document.querySelector("#check").style.width='50%';
    setinputfield(true);
    // document.querySelector(".check").style.width='50px'
  } else {
    // document.querySelector("#check").style.display='none';
    document.querySelector("#check").style.width='0px';
    setinputfield(false);
    // document.querySelector(".check").style.width='1px'

  }
};

window.addEventListener('scroll',changetransition);


  return (
    <div >



      <nav className={colorChange?"navbar navbar-expand-lg bg-light":"navbar navbar-expand-lg"} style={{position:'fixed',width:'100%',top:0,height:matches2?'100px':'70px'}} >
       
  <div className="container-fluid">
    <div className='mx-4' style={{display:matches1?'none':'block'}}>

    <i className="material-icons btn-nav" onClick={openNav}>menu</i>
   
    </div>
  
  <div >
    <Link className="navbar-brand " to='/' style={{fontSize:matches2?'45px':'30px'}}>Uber <span style={{fontWeight:'500'}}> Eats</span></Link>


  </div>
    
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
     

<div id='check' style={{ height:'60px',display:"flex",visibility:inputfield?"visible":"hidden",justifyContent:'center',alignItems:'center',backgroundColor:'#E6E6E6',marginLeft:matches3?'8%':'5px'}}>
<i className='material-icons mx-3' style={{fontSize:'26px'}}>place</i> 
 
<input type="text"  class="form-control check" id="formGroupExampleInput" 
style={{border:'none',boxShadow:'none',borderRadius:'0px',backgroundColor:'#E6E6E6'}} placeholder="Enter the Address Details"/>
</div>


{/* <div style={{display:'flex',justifyContent:'start',alignItems:'center',backgroundColor:'#fff'}}>
     <i className='material-icons mx-3' style={{fontSize:'24px'}}>place</i>

      <input type="text" placeholder='Enter delivery address' style={{border:'none',outline:'none',height:'50px'}}/>  
  </div> */}

     
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
       
        
      
       
      </ul>
      <div className="sidenav " id="mySidenav" style={{side}}>
      <Link to="/" class="closebtn" onclick={closeNav}>&times;</Link>

      <button className="btn btn-login mx-5 my-3" type="submit" style={{display:'flex',justifyContent:'center',alignItems:'center'}}><i className="fas fa-user-alt" style={{fontSize:'16px'}}></i> Log in</button>
        
        <button className="btn-signup mx-5" type="submit" style={{display:'flex',justifyContent:'center',alignItems:'center'}}>Sign-up</button>
      </div>
      <div className='d-flex'>

      <button className="btn btn-login " ><i className="fa fa-user" style={{fontSize:'20px'}}></i> Log in</button>
        
        <button className=" mx-5 btn-signup" >Sign-up</button>
      </div>
    </div>
  </div>
</nav>


<OrderFood/>


    </div>
  )
}

export default Navbar
