import React from 'react'
import { Link } from 'react-router-dom'
import FooterBigscreen from './FooterBigscreen'
import MapPath from './MapPath'

const Map = () => {
  return (
    <>
<div style={{padding:'0px 20px'}}>
    <div className="row">
     <div style={{display:'flex',alignItems:'center'}}>

<div className='col-sm-6' style={{color:'#000',fontSize:'2.3vw',fontWeight:'500'}}> <span> Cities near me </span>  </div>
<div className='col-sm-6 text-end'> <span>  <Link to='/' style={{color:'#000'}}>View all 500+ cities</Link>  </span>


</div>
     </div>
     </div>
    
     </div>


  

     <div className='col-sm-12 ' >
<MapPath/>


</div>


    </>
  )
}

export default Map
