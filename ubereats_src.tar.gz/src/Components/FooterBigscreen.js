import React from 'react'
import { Link } from 'react-router-dom';
import applestore from "../Images/applestore.svg";
import gplaystore from "../Images/gplaystore.png";

const FooterBigscreen = () => {
  let linkcolor = {
    color:'#000',
    textDecoration:'none'
  }
  return (
    <>
    <div style={{marginTop:'70rem'}}>
      <hr style={{border:'1px solid #000'}}/>
    </div>

<div style={{padding:'0px 20px'}}>
<div className="row">
<div className="col-sm-6" style={{paddingLeft:'20px'}}>
 <div className='my-5' style={{fontSize:'2.5vw',fontWeight:500}}><span> Uber</span></div> 

<div style={{display:'flex',margin:'100px 0px'}}>

<div> <Link to="/" style={linkcolor}><img src={applestore}  /></Link> </div>
<div className='mx-3'> <Link to="/" style={linkcolor}><img src={gplaystore} width={135} /></Link> </div>

</div>



</div>


<div className="col-sm-6 my-5">

  <div className="col-sm-12">
  <div className="row" >
<div className='col-sm-6' >
<p><Link to='/' style={linkcolor}>Get Help  </Link></p>
<p><Link to='/' style={linkcolor}>Buy gift cards  </Link></p>
<p><Link to='/' style={linkcolor}>Add your restaurant  </Link></p>
<p><Link to='/' style={linkcolor}>Sign up to deliver </Link></p>
<p><Link to='/' style={linkcolor}>Create a business account  </Link></p>
<p><Link to='/' style={linkcolor}>Promotions </Link></p>






</div>

<div className='col-sm-6'>
<p><Link to='/' style={linkcolor}>Restaurants near me </Link></p>
<p><Link to='/' style={linkcolor}>View all cities </Link></p>
<p><Link to='/' style={linkcolor}>View all countries </Link></p>
<p><Link to='/' style={linkcolor}>Pickup near me </Link></p>
<p><Link to='/' style={linkcolor}>About Uber Eats </Link></p>
<p><Link to='/' style={linkcolor}><i class="fa fa-language" aria-hidden="true"></i> &nbsp;&nbsp; English </Link></p>

</div>



</div>
</div>


</div>

</div>
<div><hr style={{color:'grey'}}/></div>
<div style={{margin:'80px 0px'}}>
<div className="row">
<div className="col-sm-4">

<div style={{display:'flex',alignItems:'center',fontSize:'18px',paddingLeft:'20px'}}>
  <div><Link to="/"><i class="fa fa-facebook" style={{color:'#fff',backgroundColor:'#000',padding:'2px 2px 0px 4px'}}></i></Link> </div> 
  <div className='mx-4'><Link to="/"><i class="fa fa-twitter" style={{color:'#000'}}></i></Link></div> 
  <div><Link to="/"><i class="fa fa-instagram" style={{color:'#000',}}></i></Link></div> 


</div>

</div>

<div className="col-sm-8">
<div style={{display:'flex',justifyContent:'end',alignItems:'center',whiteSpace:'nowrap',fontSize:'14px'}}>

<div><p><Link to="/" style={linkcolor}>Privacy Policy</Link></p></div>

<div style={{margin:'0px 30px'}}><p><Link to="/" style={linkcolor}>Terms</Link></p></div>

<div><p><Link to="/" style={linkcolor}>Pricing</Link></p></div>

<div style={{marginLeft:'30px'}}><p><Link to="/" style={linkcolor}>Do not sell my info (California)</Link></p></div>




</div>

<div style={{display:'flex',justifyContent:'end',alignItems:'center',whiteSpace:'nowrap',fontSize:'14px'}}>
<div style={{marginRight:'30px'}}><p> This site is protected by reCAPTCHA and the Google <Link to='/' style={{color:'#000'}}>Privacy Policy</Link> and <Link to='/' style={{color:'#000'}}>Terms of Service </Link> apply.</p> </div>
<div><p>© 2022 Uber Technologies Inc.</p> </div>

</div>



</div>

</div>

</div>




</div>

    </>
  )
}

export default FooterBigscreen
