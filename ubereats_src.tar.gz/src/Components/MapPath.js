
import { GoogleMap, useJsApiLoader, Marker, Autocomplete, DirectionsRenderer } from '@react-google-maps/api';
import { useRef, useState } from 'react';
import FooterBigscreen from './FooterBigscreen';

const center = {
  lat: 26.8963359,
  lng: 80.9760448
};
function App() {

  const [directionsResponse, setDirectionsResponse] = useState(null)
  const [distance, setDistance] = useState('')
  const [duration, setDuration] = useState('')
  const Origenref = useRef();
  const destinationref = useRef();

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: "AIzaSyAbwv5P-iff_vVB7TpstiQ1RI1kvktza48",
    libraries: ['places']

  })
  async function Calculate() {
    if (Origenref.current.value === '' || destinationref.current.value == '') {
      return
    }
    // eslint-disable-next-line
    const DirectionsService = new google.maps.DirectionsService()
    const result = await DirectionsService.route({
      origin: Origenref.current.value,
      destination: destinationref.current.value,
      // eslint-disable-next-line
      travelMode: google.maps.TravelMode.DRIVING
    })
    setDirectionsResponse(result)
    setDistance(result.routes[0].legs[0].distance.text)
    setDuration(result.routes[0].legs[0].distance.text)

  }

  function Clear() {
    setDirectionsResponse(null)
    setDistance('')
    setDuration('')
    Origenref.current.value = ''
    destinationref.current.value = ''


  }



  return isLoaded ? (
    <>

      {/* <div className='container w-25  d-md-flex justify-content-between align-items-center' style={{ position: 'absolute', top: '50px', left: '0', right: '0',zIndex:100 }}>
        <div className="input-group  ">

          <Autocomplete >
            <input ref={Origenref} style={{ width: '100%' }} type="text" className="form-control " aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" />
          </Autocomplete>
        </div>

        <div className="input-group  " >

          <Autocomplete>
            <input ref={destinationref} type="text" className="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" />
          </Autocomplete>
        </div>

        <button onClick={Calculate} type="button" className="btn btn-warning mx-3 ">Search</button>
        <button onClick={Clear} type="button" className="btn btn-danger mx=3">Clear</button>

      </div> */}

      <div className='container-fluid' style={{ left:'15px',height: '400px', width: '98%', position: 'absolute', zIndex: '100'}}>


        <GoogleMap
          mapContainerStyle={{ height: '100%', width: '100%', position: 'absolute', left: 0 }}
          center={center}
          zoom={4}


        >
          <Marker position={center} />
          {
            directionsResponse && <DirectionsRenderer directions={directionsResponse} />
          }
        </GoogleMap>


      </div>

      <div className="col-sm-12 " style={{marginTop:'450px',zIndex:100,position:'absolute',padding:'0px 20px'}}>
<div className="row">
<div style={{display:'flex',alignItems:'center',cursor:'pointer'}}>
<div className="col-sm-3">
<p>Akron </p>

<p> Albuquerque </p>
<p> Bridgeport </p>
<p> Concord </p>
<p> Dayton </p>
<p> El Paso </p>

</div>


<div className="col-sm-3">
 <p>Hartford</p>
 <p>Houston</p>
 <p>Indianapolis</p>
 <p>McAllen</p>
 <p>Mesa</p>
 <p>Milwaukee</p>
 
</div>


<div className="col-sm-3">

<p>Nashville</p>
<p>New Orleans</p>
<p>Oklahoma City</p>
<p>Omaha</p>
<p>Orlando</p>
<p>Palm Bay</p>

</div>


<div className="col-sm-3">

<p>Providence</p>
 <p>Queens</p>
 <p>San Antonio</p>
 <p>Stony Brook</p>
<p>Tucson</p>
<p>West Hollywood</p>
</div>



</div>


</div>
</div>



<div className='col-sm-12' style={{position:'absolute',zIndex:100,marginTop:'42rem',padding:'0px 20px'}}>
<div className='my-4' style={{fontSize:'2.4vw',fontWeight:500}}> <span>Countries with Uber Eats</span> </div>

<div className="row">

<div style={{display:'flex',cursor:'pointer',alignItems:'center'}}>

<div className="col-sm-3">
<p>Australia </p>
<p>Belgium </p>
<p>Bolivia </p>
<p>Canada </p>
<p>Chile </p>
<p>Costa Rica </p>
<p>Dominican Republic </p>
<p>Ecuador </p>

</div>


<div className="col-sm-3">
<p>El Salvador</p>
<p>France</p>
<p>Germany</p>
<p>Guatemala</p>
<p>Ireland</p>
<p>Italy</p>
<p>Japan</p>
<p>Kenya</p>

</div>


<div className="col-sm-3">
<p>Mexico</p>
<p>Netherlands</p>
<p>New Zealand</p>
<p>Panama</p>
<p>Poland</p>
<p>Portugal</p>
<p>Réunion</p>
<p>South Africa</p>

</div>

<div className="col-sm-3">
<p>Spain</p>
<p>Sri Lanka</p>
<p>Sweden</p>
<p>Switzerland</p>
<p>Taiwan (ROC)</p>
<p>United Kingdom</p>
<p>United States</p>

</div>


</div>
</div>

</div>


    </>
    
  ) : <></>
}

export default App;