import React from 'react'
import useMediaQuery from '@mui/material/useMediaQuery';
import ubereat from "../Images/ubereat.png";
import { margin } from '@mui/system';

import Map from './Map';
import FooterBigscreen from './FooterBigscreen';
import { Link } from 'react-router-dom';
import BigscreenOnCards from './BigscreenOnCards';



const OrderFood = () => {

    const matches1 = useMediaQuery('(min-width:1350px)');
    const matches2 = useMediaQuery('(min-width:820px)');
    const matches3 = useMediaQuery('(min-width:720px)');
   
    const matches4 = useMediaQuery('(min-width:460px)');



    
  return (
    <>

    <div style={{display:matches2?'block':'none'}}>
<div style={{position:'absolute',zIndex:-1,left:0,top:0 ,width:'100%',backgroundRepeat:'no-repeat',backgroundPosition:'center',backgroundAttachment:'fixed'}}>
<img src={ubereat} style={{width:'100%',height:matches4?'100%':'1200px'}} alt="" />
</div>


<div className='col-sm-12' style={{padding:'10% 20px',paddingLeft:'50px'}}>
    <h1 className='my-5' style={{fontSize:'5vw',fontWeight:'500',color:'#000'}}> Order food to your door </h1>  
 
 
  <div className="row">

    <div style={{display:'flex'}}>
     <div className={matches1?'col-sm-6':'col-sm-4'} style={{display:'flex',justifyContent:'start',alignItems:'center' ,backgroundColor:'#fff',padding:matches1?'22px':'10px'}}>
     <i className={matches1?'material-icons mx-4':'material-icons mx-2'} style={{fontSize:matches1?'30px':'20px',color:'#000'}}>place</i>
 
    
      <input type="text" placeholder='Enter delivery address' style={{border:'none',outline:'none',fontSize:matches1?'20px':'11px'}}/>  
  </div>

  <div className={matches1?'col-sm-2':'col-sm-4'} style={{display:'flex' ,justifyContent:'center',alignItems:'center'}}>

<div className="dropdown">
  <button className="dropdown-toggle"  type="button" data-bs-toggle="dropdown" aria-expanded="false" style={{backgroundColor:'#fff',border:'none',color:'#000',fontWeight:'500',padding:'25px',fontSize:'20px'}}>
  <i className="fa fa-clock-o" style={{fontSize:"20px",paddingRight:'10px',color:'#000'}}></i> Deliver Now

  </button>
  <ul className="dropdown-menu">
    <li > <Link className="dropdown-item" to="/" style={{color:'#000',fontWeight:'450',padding:'18px'}}><i className="fa fa-clock-o" style={{fontSize:"18px",paddingRight:'10px',color:'#000'}}></i> Deliver now</Link></li>
    <li><Link className="dropdown-item" to="/" style={{color:'#000',fontWeight:'450',padding:'18px'}}><i class='fa fa-calendar-o' style={{fontSize:'18px',paddingRight:'10px',color:'#000'}}></i> Schedule for later</Link></li>
  
  </ul>
</div>

</div>

<div className={matches1?"col-sm-2":'col-sm-4'} >

<button style={{border:'none', color:'#fff',fontSize:'25px',backgroundColor:'#000',padding:'20px',whiteSpace:'nowrap'}}>  Find Food</button>

</div>

</div>

</div>

<div className='mt-5' style={{fontSize:'20px',color:'#000'}}>
<span> <Link to="/" style={{cursor:'pointer',color:'#000'}}>Sign In</Link>  for your recent addresses </span>
</div>

</div>
<BigscreenOnCards/>
<Map/>
<FooterBigscreen/>



</div>
{/* ..........................above code 820px.......................................... */}

<div style={{display:matches2?'none':'block'}}>

<div style={{position:'absolute',zIndex:-1,left:0,top:0,height:'100%' ,width:'100%',backgroundRepeat:'no-repeat',backgroundPosition:'center',backgroundAttachment:'fixed'}}>
<img src={ubereat} style={{width:'100%',height:'800px'}} alt="" />
</div>


<div className='my-5' style={{textAlign:'center',color:'#000',padding:'5rem 0px'}}>

  <div>

  <span style={{fontSize:matches4?'38px':'30px',paddingLeft:matches4?'':'10px',fontWeight:'500'}}>Order food to your door</span>
  </div>

  <div style={{display:'flex',justifyContent:'center',alignItems:'center',marginTop:'35px'}}>
     <div style={{display:'flex',justifyContent:'start',alignItems:'center',backgroundColor:'#fff',width:matches4?'50%':'80%'}}>
     <i className={matches4?'material-icons mx-3':'material-icons mx-2'} style={{fontSize:matches4?'24px':'20px'}}>place</i>

      <input type="text" placeholder='Enter delivery address' style={{border:'none',outline:'none',height:'50px',width:matches4?'50%':'80%'}}/>  
  </div>
   </div>


   <div className='my-2' style={{display:'flex',justifyContent:'center',alignItems:'center'}}>

<div  style={{backgroundColor:'#fff',width:matches4?'50%':'80%',display:'flex',justifyContent:'start',alignItems:'center',whiteSpace:'nowrap'}}>
 
  <button type="button" data-bs-toggle="dropdown" aria-expanded="false" style={{border:'none',height:'50px',backgroundColor:'#fff'}}>
  <i className="fa fa-clock-o mx-3" ></i> Deliver Now
  </button>
  
<i className="fa fa-angle-down mx-3" style={{fontSize:"24px",paddingLeft:matches4?'':'50px'}}></i>



</div>


</div>






<div className='my-2' >
<button style={{height:'50px',width:matches4?'50%':'80%',border:'none', color:'#fff',fontSize:'18px',backgroundColor:'#000',whiteSpace:'nowrap'}}>Find Food</button>

</div>



<div>


</div>

<div className='my-4' style={{fontSize:'16px',color:'#000',paddingRight:'160px',whiteSpace:'nowrap',paddingLeft:matches4?'':'40px'}}>
<span> <Link to="/" style={{cursor:'pointer',color:'#000'}}>Sign In </Link> for your recent addresses </span>
</div>


   </div>
   </div>


    </>
  )
}

export default OrderFood



