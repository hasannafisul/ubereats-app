import "./App.css";
import React from 'react'
import Navbar from './Components/Navbar'
import {
  BrowserRouter as Router,
Routes,
  Route,

} from "react-router-dom";



const App = () => {
 
  return (
    <div>
      <Router>
<Routes>

<Route exact path='/' element={< Navbar />}></Route>  
</Routes>
      </Router>
   



  
    </div>
  )
}

export default App






// // import React from "react";
  

// //     export default function App() {

    
// //       return (
// //         <div className="App">
// //           <button onMouseOver={(event)=>{
// // event.target.style.background ='green'
// //           }} onMouseOut={(event)=>{
// //             event.target.style.background ='yellow'
// //           }}>Hover over me!</button>
// //         </div>
// //       );
// //     }




// import React, { useEffect, useState } from 'react'

// const App = () => {
//   const [offset, setOffset] = useState(0);
//   useEffect(() => {
//     const onScroll = () => setOffset(window.pageYOffset);
//     // clean up code
//     window.removeEventListener('scroll', onScroll);
//     window.addEventListener('scroll', onScroll, { passive: true });
//     return () => window.removeEventListener('scroll', onScroll);
// }, []);
// console.log(offset); 

// return (
//   <div>
      
//     </div>
//   )
// }

// export default App




// import React, { useState } from "react";

// // Generate some dummy data
// const DUMMY_DATA = Array.from({ length: 100 }, (x, i) => {
//   return {
//     id: i,
//     title: `Item ${i}`,
//   };
// });

// const App = () => {
//   const [progress, setProgress] = useState(0);
//   const styles = {
//     container: {
     
//       overflowY: "auto",
//       overflowX: "hidden",
//       background: "orange",
//     },
   
   
//     progressBar: {
//       width: 600,
//       height: 20,
//       margin: "auto",
//       backgroundColor: "#bbb",
//     },
//     progressValue: {
//       height: "100%",
//       backgroundColor: "blue",
//     },
//     text: {
//       textAlign: 'center'
//     }
//   };

//   // This function is triggered when the user scroll
//   const scrollHandler = (event) => {
//     const containerHeight = event.currentTarget.clientHeight;
//     const scrollHeight = event.currentTarget.scrollHeight;

//     const scrollTop = event.currentTarget.scrollTop;
//     setProgress(((scrollTop + containerHeight) / scrollHeight) * 100);
//   };

//   return (
//     <>
//       {/* The container */}
//       <div style={styles.container} onScroll={scrollHandler}>
//         {/* The list */}
//         <div style={styles.list}>
//           {DUMMY_DATA.map((item) => (
//             // A single item
//             <div style={styles.item} key={item.id}>
//               {item.title}
//             </div>
//           ))}
//         </div>
//       </div>

//       {/* The progress bar */}
//       <div style={styles.progressBar}>
//         <div style={{ ...styles.progressValue, width: `${progress}%` }}></div>
//       </div>
//       <p style={styles.text}>{progress.toFixed(2)}%</p>
//     </>
//   );
// };

// // Styling


// export default App;







// import React from 'react'

// const App = () => {
//   return (
//     <>
//         <div style={{border:'2px solid red',width:'10px'}}>  
// <div style={{width:'1px',display:'flex',justifyContent:'center',alignItems:'center',backgroundColor:'#E6E6E6'}}>
// <i className='material-icons mx-3' style={{backgroundColor:'red',fontSize:'26px'}}>place</i> 
 
// <input type="text" class="form-control " id="formGroupExampleInput" 
// style={{border:'none',boxShadow:'none' ,borderRadius:'0px',backgroundColor:'#E6E6E6'}} placeholder="Enter the Address Details"/>
// </div>
// </div>
//     </>
//   )
// }

// export default App

